#ifndef _TEST_COMMON_HPP_
#define _TEST_COMMON_HPP_

#define CATCH_CONFIG_MAIN
#include "catch.hpp"

#endif // _TEST_COMMON_HPP_
