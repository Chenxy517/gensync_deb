/* This code is part of the GenSync project developed at Boston University.  Please see the README for use and references. */

#include <GenSync/Aux/UID.h>
int UID::ID_count = 0; // initialize the static field
